const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const encryption = require('../utils/encryption');

module.exports = (io, db) => {
  const activeCalls = new Map();
  const userSockets = new Map();
  const pendingMessages = new Map();

  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) {
      return next(new Error('Authentication error'));
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.userId;
      socket.username = decoded.username;
      next();
    } catch (err) {
      console.error('Socket auth error:', err);
      next(new Error('Authentication error'));
    }
  });

  io.on('connection', async (socket) => {
    console.log(`✅ User connected: ${socket.username} (${socket.userId})`);
    
    userSockets.set(socket.userId, socket);
    
    try {
      await db.updateUserOnlineStatus(socket.userId, true, socket.handshake.address, 5000);
      
      // Send any pending messages for this user
      const pending = pendingMessages.get(socket.userId) || [];
      if (pending.length > 0) {
        console.log(`📦 Sending ${pending.length} pending messages to ${socket.username}`);
        pending.forEach(msg => {
          socket.emit('message:private', msg);
        });
        pendingMessages.delete(socket.userId);
      }
    } catch (error) {
      console.error('Failed to update user status:', error);
    }
    
    socket.broadcast.emit('user:joined', {
      userId: socket.userId,
      username: socket.username,
      avatarData: null
    });

    try {
      const onlineUsers = await db.getOnlineUsers();
      const filtered = onlineUsers.filter(u => u.id !== socket.userId);
      socket.emit('online:users', filtered);
    } catch (error) {
      console.error('Failed to get online users:', error);
    }

    // Handle private messages with large content support
    socket.on('message:private', async (data) => {
      try {
        const { receiverId, content } = data;
        
        if (!receiverId || !content) {
          socket.emit('error', { message: 'Invalid message data' });
          return;
        }
        
        const messageId = uuidv4();
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
        const timestamp = new Date().toISOString();
        
        // Check content size and handle large messages (images, files)
        let contentToStore = content;
        let messageToSend = content;
        let isLargeContent = false;
        const MAX_CONTENT_SIZE = 500000; // 500KB limit for storage
        
        if (typeof content === 'string' && content.length > MAX_CONTENT_SIZE) {
          // Truncate large text/images for storage
          contentToStore = '[Large content truncated]';
          messageToSend = content.length > 1000 ? '[Large message]' : content;
          isLargeContent = true;
          console.log(`Large message truncated: ${content.length} chars`);
        } else if (typeof content === 'object' && content.url && content.url.length > MAX_CONTENT_SIZE) {
          // Handle large images/files
          contentToStore = { ...content, url: '[Image data truncated]', truncated: true };
          messageToSend = { ...content, url: content.url.substring(0, 100) + '...[truncated]' };
          isLargeContent = true;
          console.log(`Large image truncated: ${content.url.length} chars`);
        } else if (typeof content === 'object' && content.type === 'image') {
          // Compress image data for storage
          if (content.url && content.url.length > MAX_CONTENT_SIZE) {
            contentToStore = { type: 'image', url: '[Image data truncated]', truncated: true };
            messageToSend = { type: 'image', url: content.url.substring(0, 100) + '...[truncated]' };
            isLargeContent = true;
          }
        }
        
        // Save message to database
        await db.saveMessage({
          id: messageId,
          senderId: socket.userId,
          receiverId: receiverId,
          content: typeof contentToStore === 'string' ? contentToStore : JSON.stringify(contentToStore),
          encryptedContent: encryption.encrypt(typeof content === 'string' ? content : JSON.stringify(content)),
          expiresAt
        });

        const messageData = {
          id: messageId,
          senderId: socket.userId,
          senderUsername: socket.username,
          content: isLargeContent ? (typeof messageToSend === 'object' ? messageToSend : '[Large message]') : content,
          timestamp: timestamp,
          isDelivered: false,
          type: typeof content === 'object' ? content.type : 'text'
        };

        // Check if receiver is online
        const receiverSocket = userSockets.get(receiverId);
        if (receiverSocket && receiverSocket.connected) {
          receiverSocket.emit('message:private', messageData);
          await db.markMessageAsDelivered(messageId);
          socket.emit('message:delivered', { messageId });
          console.log(`📨 Message sent to ${receiverId} (online)`);
        } else {
          // Store for offline delivery
          const pending = pendingMessages.get(receiverId) || [];
          pending.push(messageData);
          pendingMessages.set(receiverId, pending);
          socket.emit('message:queued', { messageId });
          console.log(`📦 Message queued for ${receiverId} (offline)`);
        }
      } catch (error) {
        console.error('Private message error:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Handle group messages with large content support
    socket.on('message:group', async (data) => {
      try {
        const { groupId, content } = data;
        
        const messageId = uuidv4();
        const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
        const timestamp = new Date().toISOString();
        
        // Handle large group messages
        let contentToStore = content;
        let messageToSend = content;
        const MAX_CONTENT_SIZE = 500000;
        
        if (typeof content === 'string' && content.length > MAX_CONTENT_SIZE) {
          contentToStore = '[Large content truncated]';
          messageToSend = content.length > 1000 ? '[Large message]' : content;
        } else if (typeof content === 'object' && content.url && content.url.length > MAX_CONTENT_SIZE) {
          contentToStore = { ...content, url: '[Image data truncated]', truncated: true };
          messageToSend = { ...content, url: '[Image]' };
        }
        
        // Get group members
        const members = await db.getGroupMembers(groupId);
        
        // Save group message
        await db.saveGroupMessage({
          id: messageId,
          groupId: groupId,
          senderId: socket.userId,
          content: typeof contentToStore === 'string' ? contentToStore : JSON.stringify(contentToStore),
          expiresAt
        });

        const messageData = {
          id: messageId,
          groupId: groupId,
          senderId: socket.userId,
          senderUsername: socket.username,
          content: messageToSend,
          timestamp: timestamp,
          type: typeof content === 'object' ? content.type : 'text'
        };

        // Send to all group members
        members.forEach(member => {
          if (member.id !== socket.userId) {
            const memberSocket = userSockets.get(member.id);
            if (memberSocket && memberSocket.connected) {
              memberSocket.emit('message:group', messageData);
            } else {
              // Store offline group messages
              const pending = pendingMessages.get(member.id) || [];
              pending.push({ ...messageData, type: 'group' });
              pendingMessages.set(member.id, pending);
            }
          }
        });
        
        console.log(`👥 Group message sent to ${members.length} members`);
      } catch (error) {
        console.error('Group message error:', error);
      }
    });

    // Handle typing indicators
    socket.on('typing:start', (data) => {
      const receiverSocket = userSockets.get(data.receiverId);
      if (receiverSocket) {
        receiverSocket.emit('typing:start', {
          userId: socket.userId,
          username: socket.username
        });
      }
    });

    socket.on('typing:stop', (data) => {
      const receiverSocket = userSockets.get(data.receiverId);
      if (receiverSocket) {
        receiverSocket.emit('typing:stop', {
          userId: socket.userId,
          username: socket.username
        });
      }
    });

    // Handle group typing
    socket.on('group:typing', async (data) => {
      try {
        const members = await db.getGroupMembers(data.groupId);
        members.forEach(member => {
          if (member.id !== socket.userId) {
            const memberSocket = userSockets.get(member.id);
            if (memberSocket && memberSocket.connected) {
              memberSocket.emit('group:typing', {
                groupId: data.groupId,
                userId: socket.userId,
                username: socket.username,
                isTyping: data.isTyping
              });
            }
          }
        });
      } catch (error) {
        console.error('Group typing error:', error);
      }
    });

    // Handle WebRTC calls
    socket.on('call:offer', (data) => {
      const callId = uuidv4();
      const callData = {
        callId,
        callerId: socket.userId,
        callerUsername: socket.username,
        receiverId: data.receiverId,
        offer: data.offer,
        type: data.type || 'audio',
        status: 'ringing',
        startedAt: Date.now()
      };
      
      activeCalls.set(callId, callData);

      const receiverSocket = userSockets.get(data.receiverId);
      if (receiverSocket && receiverSocket.connected) {
        receiverSocket.emit('call:incoming', {
          callId,
          callerId: socket.userId,
          callerUsername: socket.username,
          offer: data.offer,
          type: data.type || 'audio'
        });
        console.log(`📞 Incoming call from ${socket.username} to ${data.receiverId}`);
      } else {
        socket.emit('error', { message: 'User is offline' });
        activeCalls.delete(callId);
      }
    });

    socket.on('call:answer', (data) => {
      const call = activeCalls.get(data.callId);
      if (call) {
        call.status = 'active';
        const callerSocket = userSockets.get(call.callerId);
        if (callerSocket && callerSocket.connected) {
          callerSocket.emit('call:answered', {
            callId: data.callId,
            answer: data.answer
          });
          console.log(`📞 Call ${data.callId} answered`);
        }
      }
    });

    socket.on('call:reject', (data) => {
      const call = activeCalls.get(data.callId);
      if (call) {
        const callerSocket = userSockets.get(call.callerId);
        if (callerSocket && callerSocket.connected) {
          callerSocket.emit('call:rejected', {
            callId: data.callId,
            reason: 'rejected'
          });
        }
        
        // Save call log
        const duration = Math.floor((Date.now() - (call.startedAt || Date.now())) / 1000);
        db.db.run(
          `INSERT INTO call_logs (id, caller_id, receiver_id, type, duration, status, started_at, ended_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [uuidv4(), call.callerId, call.receiverId, call.type, duration, 'rejected', new Date(call.startedAt).toISOString(), new Date().toISOString()]
        ).catch(err => console.error('Failed to save call log:', err));
        
        activeCalls.delete(data.callId);
        console.log(`📞 Call ${data.callId} rejected`);
      }
    });

    socket.on('call:ice-candidate', (data) => {
      const call = activeCalls.get(data.callId);
      if (call) {
        const targetId = call.callerId === socket.userId ? call.receiverId : call.callerId;
        const targetSocket = userSockets.get(targetId);
        if (targetSocket && targetSocket.connected) {
          targetSocket.emit('call:ice-candidate', {
            callId: data.callId,
            candidate: data.candidate
          });
        }
      }
    });

    socket.on('call:end', async (data) => {
      const call = activeCalls.get(data.callId);
      if (call) {
        const duration = Math.floor((Date.now() - (call.startedAt || Date.now())) / 1000);
        
        // Save call log
        try {
          await db.db.run(
            `INSERT INTO call_logs (id, caller_id, receiver_id, type, duration, status, started_at, ended_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [uuidv4(), call.callerId, call.receiverId, call.type, duration, 'answered', new Date(call.startedAt).toISOString(), new Date().toISOString()]
          );
        } catch (err) {
          console.error('Failed to save call log:', err);
        }
        
        const otherId = call.callerId === socket.userId ? call.receiverId : call.callerId;
        const otherSocket = userSockets.get(otherId);
        if (otherSocket && otherSocket.connected) {
          otherSocket.emit('call:ended', { callId: data.callId });
        }
        activeCalls.delete(data.callId);
        console.log(`📞 Call ${data.callId} ended, duration: ${duration}s`);
      }
    });

    // Handle network discovery
    socket.on('discovery:broadcast', async (data) => {
      try {
        await db.registerHost(socket.userId, data.ip, data.port);
        const activeHosts = await db.getActiveHosts();
        const hostUsers = activeHosts.filter(h => h.user_id !== socket.userId);
        socket.emit('discovery:hosts', hostUsers);
      } catch (error) {
        console.error('Discovery broadcast error:', error);
      }
    });

    // Handle group creation
    socket.on('group:create', async (data) => {
      try {
        const groupId = uuidv4();
        await db.createGroup({
          id: groupId,
          name: data.name,
          creatorId: socket.userId,
          avatarData: data.avatarData
        });

        for (const memberId of data.members) {
          if (memberId !== socket.userId) {
            await db.addUserToGroup(groupId, memberId);
          }
        }

        const members = await db.getGroupMembers(groupId);
        
        members.forEach(member => {
          const memberSocket = userSockets.get(member.id);
          if (memberSocket && memberSocket.connected) {
            memberSocket.emit('group:created', {
              groupId,
              name: data.name,
              members
            });
          }
        });
        
        socket.emit('group:created', { groupId, name: data.name, members });
        console.log(`👥 Group "${data.name}" created with ${members.length} members`);
      } catch (error) {
        console.error('Group creation error:', error);
        socket.emit('error', { message: 'Failed to create group' });
      }
    });

    // Handle group join
    socket.on('group:join', async (data) => {
      try {
        await db.addUserToGroup(data.groupId, socket.userId);
        const members = await db.getGroupMembers(data.groupId);
        
        members.forEach(member => {
          const memberSocket = userSockets.get(member.id);
          if (memberSocket && memberSocket.connected) {
            memberSocket.emit('group:user-joined', {
              groupId: data.groupId,
              user: {
                id: socket.userId,
                username: socket.username,
                avatarData: null
              }
            });
          }
        });
      } catch (error) {
        console.error('Group join error:', error);
      }
    });

    // Handle group leave
    socket.on('group:leave', async (data) => {
      try {
        await db.removeUserFromGroup(data.groupId, socket.userId);
        const members = await db.getGroupMembers(data.groupId);
        
        members.forEach(member => {
          const memberSocket = userSockets.get(member.id);
          if (memberSocket && memberSocket.connected) {
            memberSocket.emit('group:user-left', {
              groupId: data.groupId,
              userId: socket.userId,
              username: socket.username
            });
          }
        });
      } catch (error) {
        console.error('Group leave error:', error);
      }
    });

    // Handle disconnection
    socket.on('disconnect', async () => {
      console.log(`❌ User disconnected: ${socket.username} (${socket.userId})`);
      userSockets.delete(socket.userId);
      
      try {
        await db.updateUserOnlineStatus(socket.userId, false);
      } catch (error) {
        console.error('Failed to update user status on disconnect:', error);
      }
      
      socket.broadcast.emit('user:left', {
        userId: socket.userId,
        username: socket.username
      });

      // End any active calls
      activeCalls.forEach((call, callId) => {
        if (call.callerId === socket.userId || call.receiverId === socket.userId) {
          const otherId = call.callerId === socket.userId ? call.receiverId : call.callerId;
          const otherSocket = userSockets.get(otherId);
          if (otherSocket && otherSocket.connected) {
            otherSocket.emit('call:ended', { 
              callId,
              reason: 'user_disconnected'
            });
          }
          activeCalls.delete(callId);
        }
      });
    });
  });

  // Cleanup expired messages every hour
  setInterval(async () => {
    try {
      await db.deleteExpiredMessages();
      console.log('🗑️ Cleaned up expired messages');
    } catch (error) {
      console.error('Failed to delete expired messages:', error);
    }
  }, 60 * 60 * 1000);
};

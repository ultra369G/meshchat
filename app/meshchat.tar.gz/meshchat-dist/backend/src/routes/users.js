const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const db = require('../database');

// Get all online users
router.get('/online', auth, async (req, res) => {
  try {
    const onlineUsers = await db.getOnlineUsers();
    const filtered = onlineUsers.filter(u => u.id !== req.userId);
    
    const formatted = filtered.map(u => ({
      userId: u.id,
      username: u.username,
      realName: u.real_name,
      real_name: u.real_name,
      avatarData: u.avatar_data,
      avatar_data: u.avatar_data,
      avatarColor: u.avatar_color,
      avatar_color: u.avatar_color,
      isOnline: u.is_online === 1
    }));
    
    res.json(formatted);
  } catch (error) {
    console.error('Get online users error:', error);
    res.status(500).json({ error: 'Failed to get online users' });
  }
});

// Get user profile
router.get('/profile/:userId', auth, async (req, res) => {
  try {
    const user = await db.getUserById(req.params.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      id: user.id,
      userId: user.id,
      username: user.username,
      realName: user.real_name,
      real_name: user.real_name,
      email: user.email,
      avatarData: user.avatar_data,
      avatar_data: user.avatar_data,
      avatarColor: user.avatar_color,
      avatar_color: user.avatar_color,
      isOnline: user.is_online === 1,
      lastSeen: user.last_seen
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

// Update user profile
router.put('/profile', auth, async (req, res) => {
  try {
    const { realName, username, avatarData, avatarColor } = req.body;
    
    if (username) {
      const existingUser = await db.getUserByUsername(username);
      if (existingUser && existingUser.id !== req.userId) {
        return res.status(400).json({ error: 'Username already taken' });
      }
      await db.db.run('UPDATE users SET username = ? WHERE id = ?', [username, req.userId]);
    }
    
    if (realName) {
      await db.db.run('UPDATE users SET real_name = ? WHERE id = ?', [realName, req.userId]);
    }
    
    if (avatarData !== undefined) {
      await db.db.run('UPDATE users SET avatar_data = ? WHERE id = ?', [avatarData, req.userId]);
    }
    
    if (avatarColor) {
      await db.db.run('UPDATE users SET avatar_color = ? WHERE id = ?', [avatarColor, req.userId]);
    }

    const updatedUser = await db.getUserById(req.userId);
    
    res.json({
      id: updatedUser.id,
      username: updatedUser.username,
      realName: updatedUser.real_name,
      avatarData: updatedUser.avatar_data,
      avatarColor: updatedUser.avatar_color
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Get user's groups
router.get('/groups', auth, async (req, res) => {
  try {
    const groups = await db.db.all(
      `SELECT g.*, 
        (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
        (SELECT COUNT(*) FROM group_messages WHERE group_id = g.id AND datetime(expires_at) > datetime("now")) as message_count
       FROM groups g
       JOIN group_members gm ON g.id = gm.group_id
       WHERE gm.user_id = ?`,
      [req.userId]
    );
    res.json(groups);
  } catch (error) {
    console.error('Get groups error:', error);
    res.status(500).json({ error: 'Failed to get groups' });
  }
});

// Get group details
router.get('/groups/:groupId', auth, async (req, res) => {
  try {
    const group = await db.getGroupById(req.params.groupId);
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    const members = await db.getGroupMembers(req.params.groupId);
    const messages = await db.db.all(
      `SELECT * FROM group_messages WHERE group_id = ? ORDER BY created_at DESC LIMIT 100`,
      [req.params.groupId]
    );
    
    res.json({
      ...group,
      members,
      messages: messages.reverse()
    });
  } catch (error) {
    console.error('Get group error:', error);
    res.status(500).json({ error: 'Failed to get group' });
  }
});

// Delete conversation
router.delete('/conversation/:userId', auth, async (req, res) => {
  try {
    const otherUserId = req.params.userId;
    
    // Delete all messages between users
    await db.db.run(
      `DELETE FROM messages 
       WHERE (sender_id = ? AND receiver_id = ?) 
       OR (sender_id = ? AND receiver_id = ?)`,
      [req.userId, otherUserId, otherUserId, req.userId]
    );
    
    res.json({ success: true, message: 'Conversation deleted' });
  } catch (error) {
    console.error('Delete conversation error:', error);
    res.status(500).json({ error: 'Failed to delete conversation' });
  }
});

// Delete group
router.delete('/groups/:groupId', auth, async (req, res) => {
  try {
    const group = await db.getGroupById(req.params.groupId);
    
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    // Check if user is creator
    if (group.creator_id !== req.userId) {
      return res.status(403).json({ error: 'Only group creator can delete group' });
    }
    
    // Delete group and all related data (cascade will handle)
    await db.db.run('DELETE FROM groups WHERE id = ?', [req.params.groupId]);
    
    res.json({ success: true, message: 'Group deleted' });
  } catch (error) {
    console.error('Delete group error:', error);
    res.status(500).json({ error: 'Failed to delete group' });
  }
});

// Leave group
router.post('/groups/:groupId/leave', auth, async (req, res) => {
  try {
    const group = await db.getGroupById(req.params.groupId);
    
    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }
    
    // If creator is leaving, transfer ownership or delete
    if (group.creator_id === req.userId) {
      const members = await db.getGroupMembers(req.params.groupId);
      const otherMembers = members.filter(m => m.id !== req.userId);
      
      if (otherMembers.length > 0) {
        // Transfer ownership to first member
        await db.db.run('UPDATE groups SET creator_id = ? WHERE id = ?', [otherMembers[0].id, req.params.groupId]);
      } else {
        // No members left, delete group
        await db.db.run('DELETE FROM groups WHERE id = ?', [req.params.groupId]);
        return res.json({ success: true, message: 'Group deleted as last member left' });
      }
    }
    
    await db.removeUserFromGroup(req.params.groupId, req.userId);
    
    res.json({ success: true, message: 'Left group' });
  } catch (error) {
    console.error('Leave group error:', error);
    res.status(500).json({ error: 'Failed to leave group' });
  }
});

// Get call logs
router.get('/calls/logs', auth, async (req, res) => {
  try {
    const logs = await db.db.all(
      `SELECT * FROM call_logs 
       WHERE caller_id = ? OR receiver_id = ? 
       ORDER BY started_at DESC LIMIT 100`,
      [req.userId, req.userId]
    );
    res.json(logs);
  } catch (error) {
    console.error('Get call logs error:', error);
    res.status(500).json({ error: 'Failed to get call logs' });
  }
});

// Save call log
router.post('/calls/logs', auth, async (req, res) => {
  try {
    const { receiverId, type, duration, status } = req.body;
    
    await db.db.run(
      `INSERT INTO call_logs (id, caller_id, receiver_id, type, duration, status, started_at, ended_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [require('crypto').randomBytes(16).toString('hex'), req.userId, receiverId, type, duration, status, new Date().toISOString(), new Date().toISOString()]
    );
    
    res.json({ success: true });
  } catch (error) {
    console.error('Save call log error:', error);
    res.status(500).json({ error: 'Failed to save call log' });
  }
});

// Get unread messages
router.get('/messages/unread', auth, async (req, res) => {
  try {
    const messages = await db.getUnreadMessages(req.userId);
    res.json(messages);
  } catch (error) {
    console.error('Get unread messages error:', error);
    res.status(500).json({ error: 'Failed to get unread messages' });
  }
});

// Get network hosts
router.get('/network/hosts', auth, async (req, res) => {
  try {
    const hosts = await db.getActiveHosts();
    res.json(hosts);
  } catch (error) {
    console.error('Get network hosts error:', error);
    res.status(500).json({ error: 'Failed to get network hosts' });
  }
});

module.exports = router;
